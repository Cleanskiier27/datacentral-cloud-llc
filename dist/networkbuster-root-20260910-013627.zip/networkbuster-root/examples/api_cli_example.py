#!/usr/bin/env python3
"""
NetworkBuster & MOONBASE.BOT - API Command Line Interface (CLI) Example.
Demonstrates how to interact with the NetworkBuster WebApp REST API via CLI.
Supports both non-interactive commands and an interactive REPL console.
Uses standard library urllib for zero external dependencies.
"""

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional

# Ensure UTF-8 console encoding on Windows
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


class NetworkBusterApiClient:
    """Client for interacting with the NetworkBuster REST API."""

    def __init__(self, base_url: str = "http://localhost:5000", timeout: float = 15.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def check_health(self) -> bool:
        """Check if the API server is reachable."""
        try:
            req = urllib.request.Request(f"{self.base_url}/", headers={"User-Agent": "NetworkBuster-CLI/1.0"})
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return resp.status == 200
        except Exception:
            return False

    def get_distro_info(self) -> Dict[str, Any]:
        """Fetch list of built distributions from GET /distro-info."""
        url = f"{self.base_url}/distro-info"
        req = urllib.request.Request(url, headers={"User-Agent": "NetworkBuster-CLI/1.0"})
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def execute_command(self, cmd_id: str) -> Dict[str, Any]:
        """Execute a flash command via POST /execute/<cmd_id>."""
        url = f"{self.base_url}/execute/{cmd_id}"
        req = urllib.request.Request(
            url,
            data=b"{}",
            headers={"Content-Type": "application/json", "User-Agent": "NetworkBuster-CLI/1.0"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def download_latest_distro(self, output_dir: str = "./downloads") -> str:
        """Download latest distribution archive from GET /download."""
        url = f"{self.base_url}/download"
        os.makedirs(output_dir, exist_ok=True)

        req = urllib.request.Request(url, headers={"User-Agent": "NetworkBuster-CLI/1.0"})
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            content_disp = resp.headers.get("Content-Disposition", "")
            filename = "networkbuster-distro.zip"
            if "download_name=" in content_disp:
                filename = content_disp.split("download_name=")[-1].strip("\"' ")
            elif "filename=" in content_disp:
                filename = content_disp.split("filename=")[-1].strip("\"' ")

            target_path = os.path.join(output_dir, filename)
            with open(target_path, "wb") as f:
                f.write(resp.read())
            return target_path


def print_banner(base_url: str):
    banner = rf"""
  _   _ _____ _______        _____  ____  _  __ ____  _   _ ____ _____ _____ ____  
 | \ | | ____|_   _\ \      / / _ \|  _ \| |/ /| __ )| | | / ___|_   _| ____|  _ \ 
 |  \| |  _|   | |  \ \ /\ / / | | | |_) | ' / |  _ \| | | \___ \ | | |  _| | |_) |
 | |\  | |___  | |   \ V  V /| |_| |  _ <| . \ | |_) | |_| |___) || | | |___|  _ < 
 |_| \_|_____| |_|    \_/\_/  \___/|_| \_\_|\_\|____/ \___/|____/ |_| |_____|_| \_\
                                                                                    
            🚀 REST API Command-Line Interface (Connected to: {base_url})
    """
    print(banner)


def cmd_status(client: NetworkBusterApiClient):
    """Check API server health and run buster_status command."""
    print("🛰️  Checking API Server Connection...")
    if not client.check_health():
        print(f"❌ Could not connect to API server at {client.base_url}")
        print("   Make sure the server is running (python webapp/app.py).")
        return

    print(f"✅ Connected to API server: {client.base_url}")
    print("\n📡 Querying BUSTER.BOT & Minecraft Server Telemetry via API...")
    try:
        res = client.execute_command("buster_status")
        print("\n--- Telemetry Output ---")
        print(res.get("stdout", "").strip() or "No output returned.")
        if res.get("stderr"):
            print("Stderr:", res["stderr"])
    except Exception as e:
        print(f"❌ Error querying status: {e}")


def cmd_distros(client: NetworkBusterApiClient):
    """List available distributions from API."""
    print("📦 Querying Available Distributions from API...")
    try:
        data = client.get_distro_info()
        if data.get("status") == "no_distro" or not data.get("distros"):
            print("ℹ️  No distributions built yet. Run 'exec moonbase_build' to package one.")
            return

        print(f"Found {len(data['distros'])} distribution archive(s):\n")
        print(f"{'Archive Name':<38} {'Size (MB)':<12} {'Created (Timestamp)'}")
        print("-" * 70)
        for d in data["distros"]:
            created_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(d["created"]))
            print(f"{d['name']:<38} {d['size_mb']:<12} {created_str}")
    except Exception as e:
        print(f"❌ Error fetching distro info: {e}")


def cmd_exec(client: NetworkBusterApiClient, cmd_id: str):
    """Execute a flash command via API."""
    print(f"⚡ Executing command '{cmd_id}' via POST /execute/{cmd_id}...")
    start_time = time.time()
    try:
        res = client.execute_command(cmd_id)
        elapsed = round(time.time() - start_time, 2)
        status_label = "✅ SUCCESS" if res.get("status") == "success" else "⚠️ FAILED / NOTICE"
        print(f"\n{status_label} (Elapsed: {elapsed}s, Code: {res.get('returncode', 0)})")
        if res.get("stdout"):
            print("\n[STDOUT]:")
            print(res["stdout"].strip())
        if res.get("stderr"):
            print("\n[STDERR]:")
            print(res["stderr"].strip())
    except urllib.error.HTTPError as e:
        print(f"❌ HTTP Error {e.code}: {e.reason}")
        try:
            err_body = json.loads(e.read().decode())
            print("   Message:", err_body.get("message", "Unknown error"))
        except Exception:
            pass
    except Exception as e:
        print(f"❌ Execution error: {e}")


def cmd_download(client: NetworkBusterApiClient, output_dir: str = "./downloads"):
    """Download the latest distribution package via API."""
    print(f"📥 Downloading latest distribution package from {client.base_url}/download...")
    try:
        saved_file = client.download_latest_distro(output_dir)
        size_kb = round(os.path.getsize(saved_file) / 1024, 2)
        print(f"✅ Download complete!")
        print(f"   Saved to: {os.path.abspath(saved_file)}")
        print(f"   Size:     {size_kb} KB")
    except urllib.error.HTTPError as e:
        print(f"❌ Download failed (HTTP {e.code}): {e.reason}")
    except Exception as e:
        print(f"❌ Error downloading distribution: {e}")


def run_interactive(client: NetworkBusterApiClient):
    """Run interactive REPL console for API commands."""
    print("=" * 70)
    print("Interactive API REPL Mode. Available commands:")
    print("  • status                 - Check API health and Minecraft/BUSTER telemetry")
    print("  • distros                - List built distribution zip packages")
    print("  • exec <cmd_id>          - Execute server command (e.g. exec moonbase_build)")
    print("  • download               - Download latest distribution archive to ./downloads")
    print("  • help                   - Show command list")
    print("  • exit / quit            - Exit the CLI")
    print("=" * 70)

    while True:
        try:
            line = input(f"\n[{client.base_url}] > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting CLI.")
            break

        if not line:
            continue

        parts = line.split()
        subcmd = parts[0].lower()

        if subcmd in ("exit", "quit", "q"):
            print("Exiting API CLI.")
            break
        elif subcmd in ("status", "health", "ping"):
            cmd_status(client)
        elif subcmd in ("distros", "list", "ls"):
            cmd_distros(client)
        elif subcmd == "exec":
            if len(parts) < 2:
                print("Usage: exec <cmd_id> (Available: moonbase_build, buster_status, build, status, web3)")
            else:
                cmd_exec(client, parts[1])
        elif subcmd in ("download", "get"):
            cmd_download(client)
        elif subcmd in ("help", "?"):
            print("Available commands: status, distros, exec <cmd_id>, download, exit")
        else:
            print(f"Unknown command '{subcmd}'. Type 'help' for available commands.")


def main():
    parser = argparse.ArgumentParser(
        description="NetworkBuster & MOONBASE.BOT REST API Command-Line Interface (CLI)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python examples/api_cli_example.py status
  python examples/api_cli_example.py distros
  python examples/api_cli_example.py exec moonbase_build
  python examples/api_cli_example.py exec buster_status
  python examples/api_cli_example.py download
  python examples/api_cli_example.py --interactive
        """
    )
    parser.add_argument(
        "--api-url",
        default=os.environ.get("NETWORKBUSTER_API_URL", "http://localhost:5000"),
        help="Base URL of the NetworkBuster API server (default: http://localhost:5000)",
    )
    parser.add_argument(
        "-i", "--interactive",
        action="store_true",
        help="Start interactive REPL console mode",
    )

    subparsers = parser.add_subparsers(dest="command", help="API Command to run")

    # status
    subparsers.add_parser("status", help="Check API health and Minecraft/BUSTER.BOT telemetry")

    # distros
    subparsers.add_parser("distros", help="List available distribution archives from GET /distro-info")

    # exec
    exec_parser = subparsers.add_parser("exec", help="Execute a flash command via POST /execute/<cmd_id>")
    exec_parser.add_argument(
        "cmd_id",
        choices=["moonbase_build", "buster_status", "build", "status", "web3", "train"],
        help="Command identifier to execute on the server",
    )

    # download
    dl_parser = subparsers.add_parser("download", help="Download latest distribution archive from GET /download")
    dl_parser.add_argument(
        "--out",
        default="./downloads",
        help="Directory to save downloaded archive (default: ./downloads)",
    )

    args = parser.parse_args()

    print_banner(args.api_url)
    client = NetworkBusterApiClient(base_url=args.api_url)

    if args.interactive or not args.command:
        run_interactive(client)
    elif args.command == "status":
        cmd_status(client)
    elif args.command == "distros":
        cmd_distros(client)
    elif args.command == "exec":
        cmd_exec(client, args.cmd_id)
    elif args.command == "download":
        cmd_download(client, output_dir=args.out)


if __name__ == "__main__":
    main()
