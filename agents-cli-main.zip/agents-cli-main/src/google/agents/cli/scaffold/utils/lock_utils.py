# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Utilities for managing uv lock files and dependencies."""

import logging
import pathlib
from pathlib import Path
from typing import NamedTuple

import yaml


class AgentConfig(NamedTuple):
    """Configuration for an agent template."""

    targets: set[str]
    dependencies: list[str]


def _scaffold_root() -> pathlib.Path:
    """Return the root of the scaffold package directory."""
    return pathlib.Path(__file__).resolve().parent.parent


EMPTY_TAG = "empty"


def _agent_tags(agent_name: str) -> list[str]:
    """Read `settings.tags` from an agent's templateconfig, [] if unreadable."""
    config_file = (
        _scaffold_root() / "agents" / agent_name / ".template" / "templateconfig.yaml"
    )
    if not config_file.exists():
        return []
    try:
        with open(config_file, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    except (OSError, yaml.YAMLError) as e:
        logging.warning("%s: could not read tags (%s).", config_file, e)
        return []
    tags = config.get("settings", {}).get("tags", [])
    return [t for t in tags if isinstance(t, str)]


def is_empty_agent(agent_name: str, tags: list[str] | None = None) -> bool:
    """True for the framework-neutral empty templates.

    They ship no agent or dependencies of their own — a framework template
    supplies the pyproject and lock — so they generate and scaffold no lock.
    Identified by the `empty` tag in templateconfig rather than by name, so the
    two can be renamed independently.
    """
    return EMPTY_TAG in (tags if tags is not None else _agent_tags(agent_name))


def get_agent_configs(
    agents_dir: pathlib.Path | None = None,
) -> dict[str, dict]:
    """Get all agents and their supported deployment targets.

    Args:
        agents_dir: Path to the agents directory. Defaults to scaffold/agents/.

    Returns:
        Dictionary mapping agent names to their configuration
    """
    if agents_dir is None:
        agents_dir = _scaffold_root() / "agents"

    agent_configs = {}

    for agent_dir in agents_dir.iterdir():
        if not agent_dir.is_dir():
            continue

        config_file = agent_dir / ".template" / "templateconfig.yaml"
        if not config_file.exists():
            continue

        with open(config_file, encoding="utf-8") as f:
            config = yaml.safe_load(f)

        agent_name = agent_dir.name
        settings = config.get("settings", {})
        # The empty templates carry no dependencies of their own, so there is
        # nothing to lock; a framework template brings its own pyproject and lock.
        if is_empty_agent(agent_name, settings.get("tags", [])):
            continue

        agent_configs[agent_name] = settings

    return agent_configs


def get_lock_filename(
    agent_name: str,
    deployment_target: str,
) -> str:
    """Generate the lock filename for a given agent and deployment target.

    Args:
        agent_name: Name of the agent
        deployment_target: Target deployment platform

    Returns:
        Formatted lock filename
    """
    return f"uv-{agent_name}-{deployment_target}.lock"


def get_lock_path(
    agent_name: str,
    deployment_target: str,
) -> Path:
    """Get the path to the appropriate lock file."""
    lock_filename = get_lock_filename(agent_name, deployment_target)
    return _scaffold_root() / "resources" / "locks" / lock_filename
