# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# IAM grants take minutes to propagate. The triggers wait on this so a push
# right after apply doesn't start a build whose service account can't yet
# write to the logs bucket.
resource "time_sleep" "wait_for_cicd_iam" {
  create_duration = "180s"

  depends_on = [
    google_project_iam_member.cicd_project_roles,
    google_project_iam_member.other_projects_roles,
  ]
}

# a. Create PR checks trigger
resource "google_cloudbuild_trigger" "pr_checks" {
  name            = "pr-${var.project_name}"
  project         = var.cicd_runner_project_id
  location        = var.region
  description     = "Trigger for PR checks"
  service_account = resource.google_service_account.cicd_runner_sa.id

  repository_event_config {
    repository = "projects/${var.cicd_runner_project_id}/locations/${var.region}/connections/${var.host_connection_name}/repositories/${var.repository_name}"
    pull_request {
      branch = "main"
    }
  }

  filename = ".cloudbuild/pr_checks.yaml"
  included_files = [
    "{{cookiecutter.agent_directory}}/**",
    "deployment/**",
{%- for path in cookiecutter.ci_trigger_files %}
    "{{ path }}",
{%- endfor %}
  ]
  include_build_logs = "INCLUDE_BUILD_LOGS_WITH_STATUS"
  depends_on = [
    resource.google_project_service.cicd_services, 
    resource.google_project_service.deploy_project_services, 
    google_cloudbuildv2_connection.github_connection, 
    google_cloudbuildv2_repository.repo,
    time_sleep.wait_for_cicd_iam
  ]
}

# b. Create CD pipeline trigger
resource "google_cloudbuild_trigger" "cd_pipeline" {
  name            = "cd-${var.project_name}"
  project         = var.cicd_runner_project_id
  location        = var.region
  service_account = resource.google_service_account.cicd_runner_sa.id
  description     = "Trigger for CD pipeline"

  repository_event_config {
    repository = "projects/${var.cicd_runner_project_id}/locations/${var.region}/connections/${var.host_connection_name}/repositories/${var.repository_name}"
    push {
      branch = "main"
    }
  }

  filename = ".cloudbuild/staging.yaml"
  included_files = [
    "{{cookiecutter.agent_directory}}/**",
    "deployment/**",
{%- for path in cookiecutter.ci_trigger_files %}
    "{{ path }}",
{%- endfor %}
  ]
  include_build_logs = "INCLUDE_BUILD_LOGS_WITH_STATUS"
  substitutions = {
    _STAGING_PROJECT_ID            = var.staging_project_id
    _LOGS_BUCKET_NAME_STAGING      = resource.google_storage_bucket.logs_data_bucket[var.staging_project_id].name
{%- if not cookiecutter.agent_identity_enabled %}
    _APP_SERVICE_ACCOUNT_STAGING   = google_service_account.app_sa["staging"].email
{%- endif %}
    _REGION                        = var.region
{%- if cookiecutter.deployment_target == 'cloud_run' %}
    _CONTAINER_NAME                = var.project_name
    _ARTIFACT_REGISTRY_REPO_NAME   = resource.google_artifact_registry_repository.repo-artifacts-genai.repository_id
{%- elif cookiecutter.deployment_target == 'gke' %}
    _CONTAINER_NAME                = var.project_name
    _ARTIFACT_REGISTRY_REPO_NAME   = resource.google_artifact_registry_repository.repo-artifacts-genai.repository_id
    _GKE_CLUSTER_NAME              = "${var.project_name}-staging"
{%- elif cookiecutter.deployment_target == 'agent_runtime' %}
{%- endif %}
    # Your other CD Pipeline substitutions
  }
  depends_on = [
    resource.google_project_service.cicd_services,
    resource.google_project_service.deploy_project_services,
    google_cloudbuildv2_connection.github_connection,
    google_cloudbuildv2_repository.repo,
    time_sleep.wait_for_cicd_iam
  ]

}

# c. Create Deploy to production trigger
resource "google_cloudbuild_trigger" "deploy_to_prod_pipeline" {
  name            = "deploy-${var.project_name}"
  project         = var.cicd_runner_project_id
  location        = var.region
  description     = "Trigger for deployment to production"
  service_account = resource.google_service_account.cicd_runner_sa.id
  repository_event_config {
    repository = "projects/${var.cicd_runner_project_id}/locations/${var.region}/connections/${var.host_connection_name}/repositories/${var.repository_name}"
  }
  filename = ".cloudbuild/deploy-to-prod.yaml"
  include_build_logs = "INCLUDE_BUILD_LOGS_WITH_STATUS"
  approval_config {
    approval_required = true
  }
  substitutions = {
    _PROD_PROJECT_ID             = var.prod_project_id
    _LOGS_BUCKET_NAME_PROD       = resource.google_storage_bucket.logs_data_bucket[var.prod_project_id].name
{%- if not cookiecutter.agent_identity_enabled %}
    _APP_SERVICE_ACCOUNT_PROD    = google_service_account.app_sa["prod"].email
{%- endif %}
    _REGION                      = var.region
{%- if cookiecutter.deployment_target == 'cloud_run' %}
    _CONTAINER_NAME              = var.project_name
    _ARTIFACT_REGISTRY_REPO_NAME = resource.google_artifact_registry_repository.repo-artifacts-genai.repository_id
{%- elif cookiecutter.deployment_target == 'gke' %}
    _CONTAINER_NAME                = var.project_name
    _ARTIFACT_REGISTRY_REPO_NAME   = resource.google_artifact_registry_repository.repo-artifacts-genai.repository_id
    _GKE_CLUSTER_NAME              = "${var.project_name}-prod"
{%- elif cookiecutter.deployment_target == 'agent_runtime' %}
{%- endif %}
    # Your other Deploy to Prod Pipeline substitutions
  }
  depends_on = [
    resource.google_project_service.cicd_services, 
    resource.google_project_service.deploy_project_services, 
    google_cloudbuildv2_connection.github_connection, 
    google_cloudbuildv2_repository.repo,
    time_sleep.wait_for_cicd_iam
  ]

}
