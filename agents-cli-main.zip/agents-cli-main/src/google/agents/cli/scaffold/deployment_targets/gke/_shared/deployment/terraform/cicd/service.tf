# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Get project information to access the project number.
# depends_on defers the read to apply time, after bootstrap has enabled Cloud
# Resource Manager.
data "google_project" "project" {
  for_each = local.deploy_project_ids

  project_id = local.deploy_project_ids[each.key]

  depends_on = [google_project_service.bootstrap]
}

{%- if cookiecutter.session_type == "cloud_sql" %}

# Ephemeral so the generated password is never persisted to Terraform state.
ephemeral "random_password" "db_password" {
  for_each = local.deploy_project_ids

  length           = 16
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

# Cloud SQL Instance
resource "google_sql_database_instance" "session_db" {
  for_each = local.deploy_project_ids

  project          = local.deploy_project_ids[each.key]
  name             = "${var.project_name}-db-${each.key}"
  database_version = "POSTGRES_15"
  region           = var.region
  deletion_protection = false # For easier teardown in starter packs

  settings {
    tier = "db-custom-1-3840"

    backup_configuration {
      enabled = true
      start_time = "03:00"
    }

    # Enable IAM authentication
    database_flags {
      name  = "cloudsql.iam_authentication"
      value = "on"
    }
  }

  depends_on = [google_project_service.deploy_project_services]
}

# Cloud SQL Database
resource "google_sql_database" "database" {
  for_each = local.deploy_project_ids

  project  = local.deploy_project_ids[each.key]
  name     = "${var.project_name}" # Use project name for DB to avoid conflict with default 'postgres'
  instance = google_sql_database_instance.session_db[each.key].name
}

# Cloud SQL User
resource "google_sql_user" "db_user" {
  for_each = local.deploy_project_ids

  project  = local.deploy_project_ids[each.key]
  name     = "${var.project_name}" # Use project name for user to avoid conflict with default 'postgres'
  instance = google_sql_database_instance.session_db[each.key].name

  # Rotate by bumping password_wo_version, secret_data_wo_version and
  # data_wo_revision together, then redeploying so running pods pick up the
  # new password.
  password_wo         = ephemeral.random_password.db_password[each.key].result
  password_wo_version = 1
}

# Store the password in Secret Manager
resource "google_secret_manager_secret" "db_password" {
  for_each = local.deploy_project_ids

  project   = local.deploy_project_ids[each.key]
  secret_id = "${var.project_name}-db-password"

  replication {
    auto {}
  }

  depends_on = [google_project_service.deploy_project_services]
}

resource "google_secret_manager_secret_version" "db_password" {
  for_each = local.deploy_project_ids

  secret                 = google_secret_manager_secret.db_password[each.key].id
  secret_data_wo         = ephemeral.random_password.db_password[each.key].result
  secret_data_wo_version = 1
}

{%- endif %}

# VPC Network
resource "google_compute_network" "gke_network" {
  for_each = local.deploy_project_ids

  name                    = "${var.project_name}-network"
  project                 = each.value
  auto_create_subnetworks = false

  depends_on = [google_project_service.deploy_project_services]
}

# Subnet for GKE cluster
resource "google_compute_subnetwork" "gke_subnet" {
  for_each = local.deploy_project_ids

  name          = "${var.project_name}-subnet"
  project       = each.value
  region        = var.region
  network       = google_compute_network.gke_network[each.key].id
  ip_cidr_range = "10.0.0.0/20"
}

# Firewall rule to allow internal traffic (metrics-server, pod-to-pod, etc.)
resource "google_compute_firewall" "allow_internal" {
  for_each = local.deploy_project_ids

  name    = "${var.project_name}-allow-internal"
  network = google_compute_network.gke_network[each.key].name
  project = each.value

  allow {
    protocol = "tcp"
  }
  allow {
    protocol = "udp"
  }
  allow {
    protocol = "icmp"
  }

  source_ranges = ["10.0.0.0/8"]
}

# GKE Autopilot Cluster
resource "google_container_cluster" "app" {
  for_each = local.deploy_project_ids

  name     = "${var.project_name}-${each.key}"
  location = var.region
  project  = each.value

  network    = google_compute_network.gke_network[each.key].name
  subnetwork = google_compute_subnetwork.gke_subnet[each.key].name

  # Enable Autopilot mode
  enable_autopilot = true

  # Use private nodes (no external IPs) for security and org policy compliance
  private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
  }

  ip_allocation_policy {
    # Let GKE auto-assign secondary ranges for pods and services
  }

  deletion_protection = false

  # Make dependencies conditional to avoid errors.
  depends_on = [
    google_project_service.deploy_project_services,
  ]
}

# Cloud Router for NAT gateway
resource "google_compute_router" "router" {
  for_each = local.deploy_project_ids

  name    = "${var.project_name}-router"
  project = each.value
  region  = var.region
  network = google_compute_network.gke_network[each.key].id
}

# Cloud NAT for private GKE nodes to access the internet
resource "google_compute_router_nat" "nat" {
  for_each = local.deploy_project_ids

  name                               = "${var.project_name}-nat"
  project                            = each.value
  router                             = google_compute_router.router[each.key].name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
}

# Artifact Registry for container images
resource "google_artifact_registry_repository" "docker_repo" {
  for_each = local.deploy_project_ids

  location      = var.region
  repository_id = var.project_name
  format        = "DOCKER"
  project       = each.value

  depends_on = [google_project_service.deploy_project_services]
}

# --- Kubernetes Resources (managed by Terraform for staging/prod) ---
# Note: Provider aliases require separate resource blocks per environment.

# Staging Kubernetes Resources

resource "kubernetes_namespace_v1" "app_staging" {
  provider = kubernetes.staging
  metadata {
    name = var.project_name
  }
  depends_on = [google_container_cluster.app]
}

resource "kubernetes_service_account_v1" "app_staging" {
  provider = kubernetes.staging
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_staging.metadata[0].name
    annotations = {
      "iam.gke.io/gcp-service-account" = google_service_account.app_sa["staging"].email
    }
  }
}

resource "kubernetes_service_v1" "app_staging" {
  provider = kubernetes.staging
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_staging.metadata[0].name
    labels = {
      app = var.project_name
    }
    annotations = {
      "cloud.google.com/load-balancer-type" = "Internal"
    }
  }
  spec {
    type = "LoadBalancer"
    port {
      port        = 8080
      target_port = 8080
      protocol    = "TCP"
    }
    selector = {
      app = var.project_name
    }
  }
}

resource "kubernetes_horizontal_pod_autoscaler_v2" "app_staging" {
  provider = kubernetes.staging
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_staging.metadata[0].name
    labels = {
      app = var.project_name
    }
  }
  spec {
    scale_target_ref {
      api_version = "apps/v1"
      kind        = "Deployment"
      name        = var.project_name
    }
    min_replicas = 2
    max_replicas = 10
    metric {
      type = "Resource"
      resource {
        name = "cpu"
        target {
          type                = "Utilization"
          average_utilization = 70
        }
      }
    }
  }
}

resource "kubernetes_pod_disruption_budget_v1" "app_staging" {
  provider = kubernetes.staging
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_staging.metadata[0].name
    labels = {
      app = var.project_name
    }
  }
  spec {
    min_available = 1
    selector {
      match_labels = {
        app = var.project_name
      }
    }
  }
}

{%- if cookiecutter.session_type == "cloud_sql" %}

resource "kubernetes_secret_v1" "db_password_staging" {
  provider = kubernetes.staging
  metadata {
    name      = "${var.project_name}-db-password"
    namespace = kubernetes_namespace_v1.app_staging.metadata[0].name
  }
  data_wo = {
    password = ephemeral.random_password.db_password["staging"].result
  }
  data_wo_revision = 1
  depends_on       = [kubernetes_namespace_v1.app_staging]
}
{%- endif %}

resource "kubernetes_deployment_v1" "app_staging" {
  provider = kubernetes.staging
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_staging.metadata[0].name
    labels = {
      app = var.project_name
    }
  }

  spec {
    selector {
      match_labels = {
        app = var.project_name
      }
    }

    template {
      metadata {
        labels = {
          app = var.project_name
        }
      }

      spec {
        # A streaming request can stay open for minutes; the 30s default would
        # SIGKILL it mid-response on any rollout or scale-down.
        termination_grace_period_seconds = 600

        service_account_name = kubernetes_service_account_v1.app_staging.metadata[0].name

        container {
          name  = var.project_name
          image = "us-docker.pkg.dev/cloudrun/container/hello"

          port {
            container_port = 8080
            protocol       = "TCP"
          }

          env {
            name  = "LOGS_BUCKET_NAME"
            value = google_storage_bucket.logs_data_bucket[var.staging_project_id].name
          }

          env {
            name  = "OTEL_SERVICE_NAME"
            value = "{{cookiecutter.project_name}}"
          }

          # Prompt/response content capture, off by default. Go: set "true" to log
          # content to OTLP log events for the completions view. Python: content goes
          # to GCS via the completion hook, so NO_CONTENT.
          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"
            value = "{{cookiecutter.otel_capture_message_content_default}}"
          }

          env {
            name  = "ADK_CAPTURE_MESSAGE_CONTENT_IN_SPANS"
            value = "false"
          }

          env {
            name  = "OTEL_SEMCONV_STABILITY_OPT_IN"
            value = "gen_ai_latest_experimental"
          }

          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_UPLOAD_FORMAT"
            value = "jsonl"
          }

          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_COMPLETION_HOOK"
            value = "upload"
          }

          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_UPLOAD_BASE_PATH"
            value = "gs://${google_storage_bucket.logs_data_bucket[var.staging_project_id].name}/completions"
          }
          env {
            name  = "GOOGLE_CLOUD_PROJECT"
            value = var.staging_project_id
          }

          env {
            name  = "GOOGLE_CLOUD_LOCATION"
            value = "global"
          }

          env {
            name  = "{{cookiecutter.genai_backend_env_var}}"
            value = "True"
          }
{%- if cookiecutter.session_type == "cloud_sql" %}
          env {
            name  = "INSTANCE_CONNECTION_NAME"
            value = google_sql_database_instance.session_db["staging"].connection_name
          }
          env {
            name = "DB_PASS"
            value_from {
              secret_key_ref {
                name = "${var.project_name}-db-password"
                key  = "password"
              }
            }
          }
          env {
            name  = "DB_NAME"
            value = var.project_name
          }
          env {
            name  = "DB_USER"
            value = var.project_name
          }
{%- endif %}
{%- if cookiecutter.supports_bq_analytics and cookiecutter.bq_analytics %}
          env {
            name  = "BQ_ANALYTICS_DATASET_ID"
            value = google_bigquery_dataset.telemetry_dataset["staging"].dataset_id
          }
          env {
            name  = "BQ_ANALYTICS_GCS_BUCKET"
            value = google_storage_bucket.logs_data_bucket[var.staging_project_id].name
          }
          env {
            name  = "BQ_ANALYTICS_CONNECTION_ID"
            value = "${var.region}.${google_bigquery_connection.genai_telemetry_connection["staging"].connection_id}"
          }
{%- endif %}

          resources {
            requests = {
              cpu    = "0.5"
              memory = "1Gi"
            }
            limits = {
              cpu    = "1"
              memory = "2Gi"
            }
          }

          startup_probe {
            tcp_socket {
              port = 8080
            }
            initial_delay_seconds = 10
            period_seconds        = 10
            failure_threshold     = 18
          }

          readiness_probe {
            tcp_socket {
              port = 8080
            }
            initial_delay_seconds = 15
            period_seconds        = 10
          }

          liveness_probe {
            tcp_socket {
              port = 8080
            }
            initial_delay_seconds = 15
            period_seconds        = 20
          }

          # Hold the pod in Terminating while the EndpointSlice removal reaches
          # every kube-proxy, so no new request lands on it before SIGTERM.
          lifecycle {
            pre_stop {
              exec {
                command = {{ cookiecutter.gke_prestop_command | tojson }}
              }
            }
          }

{%- if cookiecutter.session_type == "cloud_sql" %}
          volume_mount {
            name       = "cloudsql"
            mount_path = "/cloudsql"
          }
{%- endif %}
        }

{%- if cookiecutter.session_type == "cloud_sql" %}
        container {
          name  = "cloud-sql-proxy"
          image = "gcr.io/cloud-sql-connectors/cloud-sql-proxy:2.14.3"
          args = [
            "--structured-logs",
            "--unix-socket=/cloudsql",
            google_sql_database_instance.session_db["staging"].connection_name,
          ]

          security_context {
            run_as_non_root = true
          }

          resources {
            requests = {
              cpu    = "0.5"
              memory = "512Mi"
            }
          }

          volume_mount {
            name       = "cloudsql"
            mount_path = "/cloudsql"
          }
        }

        volume {
          name = "cloudsql"
          empty_dir {}
        }
{%- endif %}
      }
    }
  }

  lifecycle {
    ignore_changes = [
      spec[0].template[0].spec[0].container[0].image,
    ]
  }

  depends_on = [kubernetes_namespace_v1.app_staging]
}

# Production Kubernetes Resources

resource "kubernetes_namespace_v1" "app_prod" {
  provider = kubernetes.prod
  metadata {
    name = var.project_name
  }
  depends_on = [google_container_cluster.app]
}

resource "kubernetes_service_account_v1" "app_prod" {
  provider = kubernetes.prod
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_prod.metadata[0].name
    annotations = {
      "iam.gke.io/gcp-service-account" = google_service_account.app_sa["prod"].email
    }
  }
}

resource "kubernetes_service_v1" "app_prod" {
  provider = kubernetes.prod
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_prod.metadata[0].name
    labels = {
      app = var.project_name
    }
    annotations = {
      "cloud.google.com/load-balancer-type" = "Internal"
    }
  }
  spec {
    type = "LoadBalancer"
    port {
      port        = 8080
      target_port = 8080
      protocol    = "TCP"
    }
    selector = {
      app = var.project_name
    }
  }
}

resource "kubernetes_horizontal_pod_autoscaler_v2" "app_prod" {
  provider = kubernetes.prod
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_prod.metadata[0].name
    labels = {
      app = var.project_name
    }
  }
  spec {
    scale_target_ref {
      api_version = "apps/v1"
      kind        = "Deployment"
      name        = var.project_name
    }
    min_replicas = 2
    max_replicas = 10
    metric {
      type = "Resource"
      resource {
        name = "cpu"
        target {
          type                = "Utilization"
          average_utilization = 70
        }
      }
    }
  }
}

resource "kubernetes_pod_disruption_budget_v1" "app_prod" {
  provider = kubernetes.prod
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_prod.metadata[0].name
    labels = {
      app = var.project_name
    }
  }
  spec {
    min_available = 1
    selector {
      match_labels = {
        app = var.project_name
      }
    }
  }
}

{%- if cookiecutter.session_type == "cloud_sql" %}

resource "kubernetes_secret_v1" "db_password_prod" {
  provider = kubernetes.prod
  metadata {
    name      = "${var.project_name}-db-password"
    namespace = kubernetes_namespace_v1.app_prod.metadata[0].name
  }
  data_wo = {
    password = ephemeral.random_password.db_password["prod"].result
  }
  data_wo_revision = 1
  depends_on       = [kubernetes_namespace_v1.app_prod]
}
{%- endif %}

resource "kubernetes_deployment_v1" "app_prod" {
  provider = kubernetes.prod
  metadata {
    name      = var.project_name
    namespace = kubernetes_namespace_v1.app_prod.metadata[0].name
    labels = {
      app = var.project_name
    }
  }

  spec {
    selector {
      match_labels = {
        app = var.project_name
      }
    }

    template {
      metadata {
        labels = {
          app = var.project_name
        }
      }

      spec {
        # A streaming request can stay open for minutes; the 30s default would
        # SIGKILL it mid-response on any rollout or scale-down.
        termination_grace_period_seconds = 600

        service_account_name = kubernetes_service_account_v1.app_prod.metadata[0].name

        container {
          name  = var.project_name
          image = "us-docker.pkg.dev/cloudrun/container/hello"

          port {
            container_port = 8080
            protocol       = "TCP"
          }

          env {
            name  = "LOGS_BUCKET_NAME"
            value = google_storage_bucket.logs_data_bucket[var.prod_project_id].name
          }

          env {
            name  = "OTEL_SERVICE_NAME"
            value = "{{cookiecutter.project_name}}"
          }

          # Prompt/response content capture, off by default. Go: set "true" to log
          # content to OTLP log events for the completions view. Python: content goes
          # to GCS via the completion hook, so NO_CONTENT.
          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"
            value = "{{cookiecutter.otel_capture_message_content_default}}"
          }

          env {
            name  = "ADK_CAPTURE_MESSAGE_CONTENT_IN_SPANS"
            value = "false"
          }

          env {
            name  = "OTEL_SEMCONV_STABILITY_OPT_IN"
            value = "gen_ai_latest_experimental"
          }

          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_UPLOAD_FORMAT"
            value = "jsonl"
          }

          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_COMPLETION_HOOK"
            value = "upload"
          }

          env {
            name  = "OTEL_INSTRUMENTATION_GENAI_UPLOAD_BASE_PATH"
            value = "gs://${google_storage_bucket.logs_data_bucket[var.prod_project_id].name}/completions"
          }
          env {
            name  = "GOOGLE_CLOUD_PROJECT"
            value = var.prod_project_id
          }

          env {
            name  = "GOOGLE_CLOUD_LOCATION"
            value = "global"
          }

          env {
            name  = "{{cookiecutter.genai_backend_env_var}}"
            value = "True"
          }
{%- if cookiecutter.session_type == "cloud_sql" %}
          env {
            name  = "INSTANCE_CONNECTION_NAME"
            value = google_sql_database_instance.session_db["prod"].connection_name
          }
          env {
            name = "DB_PASS"
            value_from {
              secret_key_ref {
                name = "${var.project_name}-db-password"
                key  = "password"
              }
            }
          }
          env {
            name  = "DB_NAME"
            value = var.project_name
          }
          env {
            name  = "DB_USER"
            value = var.project_name
          }
{%- endif %}
{%- if cookiecutter.supports_bq_analytics and cookiecutter.bq_analytics %}
          env {
            name  = "BQ_ANALYTICS_DATASET_ID"
            value = google_bigquery_dataset.telemetry_dataset["prod"].dataset_id
          }
          env {
            name  = "BQ_ANALYTICS_GCS_BUCKET"
            value = google_storage_bucket.logs_data_bucket[var.prod_project_id].name
          }
          env {
            name  = "BQ_ANALYTICS_CONNECTION_ID"
            value = "${var.region}.${google_bigquery_connection.genai_telemetry_connection["prod"].connection_id}"
          }
{%- endif %}

          resources {
            requests = {
              cpu    = "0.5"
              memory = "1Gi"
            }
            limits = {
              cpu    = "1"
              memory = "2Gi"
            }
          }

          startup_probe {
            tcp_socket {
              port = 8080
            }
            initial_delay_seconds = 10
            period_seconds        = 10
            failure_threshold     = 18
          }

          readiness_probe {
            tcp_socket {
              port = 8080
            }
            initial_delay_seconds = 15
            period_seconds        = 10
          }

          liveness_probe {
            tcp_socket {
              port = 8080
            }
            initial_delay_seconds = 15
            period_seconds        = 20
          }

          # Hold the pod in Terminating while the EndpointSlice removal reaches
          # every kube-proxy, so no new request lands on it before SIGTERM.
          lifecycle {
            pre_stop {
              exec {
                command = {{ cookiecutter.gke_prestop_command | tojson }}
              }
            }
          }

{%- if cookiecutter.session_type == "cloud_sql" %}
          volume_mount {
            name       = "cloudsql"
            mount_path = "/cloudsql"
          }
{%- endif %}
        }

{%- if cookiecutter.session_type == "cloud_sql" %}
        container {
          name  = "cloud-sql-proxy"
          image = "gcr.io/cloud-sql-connectors/cloud-sql-proxy:2.14.3"
          args = [
            "--structured-logs",
            "--unix-socket=/cloudsql",
            google_sql_database_instance.session_db["prod"].connection_name,
          ]

          security_context {
            run_as_non_root = true
          }

          resources {
            requests = {
              cpu    = "0.5"
              memory = "512Mi"
            }
          }

          volume_mount {
            name       = "cloudsql"
            mount_path = "/cloudsql"
          }
        }

        volume {
          name = "cloudsql"
          empty_dir {}
        }
{%- endif %}
      }
    }
  }

  lifecycle {
    ignore_changes = [
      spec[0].template[0].spec[0].container[0].image,
    ]
  }

  depends_on = [kubernetes_namespace_v1.app_prod]
}
