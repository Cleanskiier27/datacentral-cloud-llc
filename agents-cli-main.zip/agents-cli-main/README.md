<div align="center">
  <img src="https://raw.githubusercontent.com/google/agents-cli/main/docs/src/assets/logo_sm.png" alt="agents-cli logo" width="120" />
  <h1><code>agents-cli</code></h1>
  <p>The CLI and skills for building agents on Gemini platform.</p>

  <p>
    <a href="#get-started">Get Started</a> &nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="#agent-skills">Skills</a> &nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="#cli-commands">Commands</a> &nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="https://pypi.org/project/google-agents-cli/">PyPI</a> &nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="https://github.com/google/agents-cli/issues">Issues</a> &nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="https://google.github.io/agents-cli/">Docs</a> &nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="https://github.com/google/agents-cli/blob/main/RELEASE_NOTES.md">Release Notes</a> &nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="https://github.com/google/agents-cli">Star us</a>
  </p>
</div>

---

Turn your favorite coding assistant into an expert at building and deploying agents on Google Cloud.

**Agents CLI in Gemini platform** (`agents-cli`) gives your coding agent the skills and commands to build, scale, govern, and optimize enterprise-grade agents — so you don't have to learn every CLI and service yourself.

**Works seamlessly with:**
[Antigravity CLI](https://antigravity.google/) &nbsp;•&nbsp; [Claude Code](https://docs.anthropic.com/en/docs/claude-code) &nbsp;•&nbsp; [Codex](https://github.com/openai/codex) &nbsp;•&nbsp; *and any other coding agent.*

## Get Started

**Prerequisites:** Python 3.11+, [uv](https://docs.astral.sh/uv/getting-started/installation/), and [Node.js](https://nodejs.org/en/download).

### 1. Install

```bash
uvx google-agents-cli setup
```

<details>
<summary>Or just the skills — your coding agent will handle the rest</summary>

```bash
npx skills add google/agents-cli
```

</details>

### 2. Open your coding agent

Launch [Antigravity CLI](https://antigravity.google/), [Claude Code](https://docs.anthropic.com/en/docs/claude-code), [Codex](https://github.com/openai/codex), or any coding agent you prefer.

### 3. Build your first agent

Ask your coding agent to build something — e.g. *"Use agents-cli to build a caveman-style agent that compresses verbose text into terse, technical grunts"*

See the [full tutorial](https://google.github.io/agents-cli/guide/quickstart-tutorial/) for a step-by-step walkthrough.

**[Browse the full documentation →](https://google.github.io/agents-cli/)**

---

## Agent Skills

| Skill | What your coding agent learns |
|-------|-------------------------------|
| `google-agents-cli-workflow` | Development lifecycle, code preservation rules, model selection |
| `google-agents-cli-adk-code` | ADK Python API — agents, tools, orchestration, callbacks, state |
| `google-agents-cli-scaffold` | Project scaffolding — `create`, `enhance`, `upgrade` |
| `google-agents-cli-eval` | Evaluation methodology — metrics, datasets, LLM-as-judge, adaptive rubrics |
| `google-agents-cli-deploy` | Deployment — [Agent Runtime in Gemini platform](https://docs.cloud.google.com/gemini-enterprise-agent-platform/scale), [Cloud Run](https://cloud.google.com/run), [GKE](https://cloud.google.com/kubernetes-engine), CI/CD, secrets |
| `google-agents-cli-publish` | Gemini registration |
| `google-agents-cli-observability` | Observability — Cloud Trace, logging, third-party integrations |

---

## CLI Commands

| Command | What it does |
|---------|-------------|
| `agents-cli setup` | Install CLI + skills to coding agents |
| `agents-cli create <name> -y` | Create a new agent project with defaults (`adk_python` template, `agent_runtime` target) |
| `agents-cli eval run` | Run the agent over the eval dataset and grade the traces |
| `agents-cli deploy` | Deploy to Google Cloud |
| `agents-cli publish gemini` | Register with Gemini |

<details>
<summary>See all commands</summary>

| Command | Description |
|---------|-------------|
| `agents-cli login` | Authenticate with Google Cloud or AI Studio |
| `agents-cli login --status` | Show authentication status |
| **Scaffold** | |
| `agents-cli create <name> -y` | Create a new agent project with defaults (`adk_python` template, `agent_runtime` target) |
| `agents-cli scaffold enhance` | Add deployment or CI/CD to an existing project |
| `agents-cli scaffold upgrade` | Upgrade project to a newer agents-cli version |
| **Develop** | |
| `agents-cli run "prompt"` | Run agent with a single prompt |
| `agents-cli install` | Install project dependencies |
| `agents-cli lint` | Run code quality checks (Ruff) |
| **Evaluate** | |
| `agents-cli eval run` | Run agent inference and grade the traces |
| `agents-cli eval generate` | Run agent inference over eval cases |
| `agents-cli eval grade` | Grade generated traces against metrics |
| `agents-cli eval dataset synthesize` | Synthesize multi-turn eval scenarios for your local agent |
| `agents-cli eval compare` | Compare two eval result files |
| `agents-cli eval analyze` | Cluster failure modes from grade results |
| `agents-cli eval metric list` | List available metrics |
| `agents-cli eval optimize` | Auto-tune agent prompts using eval data |
| **Deploy & Publish** | |
| `agents-cli deploy` | Deploy to Google Cloud |
| `agents-cli publish gemini` | Register with Gemini |
| `agents-cli infra single-project` | Provision single-project infrastructure |
| `agents-cli infra cicd` | Set up CI/CD pipeline + staging/prod infrastructure |
| **Other** | |
| `agents-cli info` | Show project config and CLI version |
| `agents-cli update` | Force reinstall skills to all IDEs |

</details>



## How it works

<div align="center">
  <a href="https://youtu.be/ECYKo70pPNc">
    <img src="https://img.youtube.com/vi/ECYKo70pPNc/maxresdefault.jpg" alt="agents-cli demo video" width="100%" />
  </a>
</div>

---

## Architecture

The Google Cloud agent stack that `agents-cli` builds on:

![Architecture](https://raw.githubusercontent.com/google/agents-cli/main/docs/src/assets/architecture.png "Architecture")

## FAQ

**Is this an alternative to Antigravity CLI, Claude Code, or Codex?**<br>
No. **`agents-cli` is a tool *for* coding agents, not a coding agent itself.** It provides the CLI commands and skills that make your coding agent better at building, evaluating, and deploying ADK agents on Google Cloud.

**How is this different from just using `adk` directly?**<br>
[ADK](https://adk.dev) is an agent framework. `agents-cli` gives your coding agent the skills and tools to build, evaluate, and deploy ADK agents end-to-end.

**Do I need Google Cloud?**<br>
For local development (`create`, `run`, `eval`), no — you can use an [AI Studio API key](https://aistudio.google.com/apikey) to run Gemini with [ADK](https://adk.dev) locally. For deployment and cloud features, yes.

**Can I use this with an existing agent project?**<br>
Yes. `agents-cli scaffold enhance` adds deployment and CI/CD to existing projects.

**Can I use `agents-cli` without a coding agent?**<br>
Yes. The CLI works standalone — you can run `agents-cli scaffold`, `eval`, `deploy`, and every other command directly from your terminal. The skills just make it easier for coding agents to do it for you.

**How can I extend `agents-cli` with other skills?**<br>
`agents-cli` skills cover the agent-building lifecycle (scaffold, ADK code patterns, evals, deploy, publish, observability). For adjacent concerns, you could install another skill suite alongside. For example, [agent-skills](https://github.com/addyosmani/agent-skills) covers general software-engineering workflows (ideation, spec gates, planning, code review), and [google/skills](https://github.com/google/skills) covers Google Cloud foundations (BigQuery, Cloud Run, Firebase, GKE). [genai-factory](https://github.com/GoogleCloudPlatform/genai-factory) has Terraform blueprints for enterprise GenAI infrastructure and ships as an extension: `agents-cli extension add GoogleCloudPlatform/genai-factory`.

## Feedback

We value your input — it helps us improve `agents-cli` for the community.

- **Bugs & feature requests:** [open an issue](https://github.com/google/agents-cli/issues/new) — 👍 the ones you want prioritized
- **Share what you built:** we'd love to hear about your projects! Reach out at <a href="mailto:agents-cli@google.com">agents-cli@google.com</a> to share your agent or provide feedback

## Contributing

The best way to contribute is through feedback: bug reports, feature requests, and ideas shared via [issues](https://github.com/google/agents-cli/issues) to directly shape our roadmap.

See the [contributing guide](CONTRIBUTING.md) for details.

## Telemetry

By default, `agents-cli` emits a single usage signal per command invocation to help
improve the tool and better understand how it's used. Each signal
is a structured log entry written to **your own Google Cloud project**:
`GOOGLE_CLOUD_PROJECT`, or else the default project of your Application Default
Credentials (`logName=projects/<project>/logs/agents-cli`), where you can query
it in Cloud Logging. It records only the metadata such as command name
(e.g. `deploy`, `scaffold.create`), exit code, error class, duration (measured
from command dispatch to exit, so it excludes CLI startup), CLI/Python versions,
and OS — never file contents, arguments, or other input. Commands added by
extensions are recorded without their names. A command an extension serves is
marked as such, and the extension is named only if it was installed from a
repository in the `google` GitHub organization.

The request that writes the entry also carries usage metadata in its
`User-Agent` and `X-Goog-Api-Client` headers, which Google receives for
agents-cli usage analytics: the CLI and Python versions, the OS and its release,
the CPU architecture, the command name and a random per-invocation ID. The log
entry's contents, such as the exit code, error class and duration, stay in your
project.

To opt out of sending telemetry, use one of the following environment variables:

```bash
# our cli-specific variable
# 0, false, no, or off (case-insensitive):
export AGENTS_CLI_TELEMETRY=0

# donottrack.sh standard variable
export DO_NOT_TRACK=1
```

Use `agents-cli info` to see the current telemetry state.

## Terms of Service

`agents-cli` leverages Google Cloud APIs. When you deploy agents, you'll be deploying resources in your own Google Cloud project and will be responsible for those resources. Please review the [Google Cloud Service Terms](https://cloud.google.com/terms/service-terms) for details.
