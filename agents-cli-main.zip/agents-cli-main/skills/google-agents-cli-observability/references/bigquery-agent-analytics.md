# BigQuery Agent Analytics Plugin

> **ADK Python and Claude template projects. Opt-in.** Enable with `--bq-analytics` at scaffold time, or add manually to `app/agent.py` (ADK). Claude projects write the same `agent_events` table and views from `app/app_utils/bq_analytics/`, without ADK-only events (state, human-in-the-loop, transfer); see the project's `agents-cli-claude` skill.

An optional ADK plugin that logs structured agent events directly to BigQuery via the Storage Write API. Enables:

- **Conversational analytics** — session flows, user interaction patterns
- **LLM-as-judge evals** — structured data for evaluation pipelines
- **Custom dashboards** — Looker Studio integration
- **Tool provenance tracking** — LOCAL, MCP, SUB_AGENT, A2A, TRANSFER_AGENT

## Enabling

| Method | How |
|--------|-----|
| **At scaffold time** | `agents-cli scaffold create <project-name> --agent adk_python --deployment-target <target> --bq-analytics` |
| **Post-scaffold** | Add the plugin manually to `app/agent.py` (see [ADK docs](https://adk.dev/integrations/bigquery-agent-analytics/index.md)) |

Infrastructure (BigQuery dataset, GCS offloading) is provisioned automatically by Terraform when enabled at scaffold time.

## Key Features

- Auto-schema upgrade (new fields added without migration)
- GCS offloading for multimodal content (images, audio)
- Distributed tracing via OpenTelemetry span context
- SQL-queryable event log for all agent interactions

For full schema, SQL query examples, and Looker Studio setup, fetch `https://adk.dev/integrations/bigquery-agent-analytics/index.md`.
