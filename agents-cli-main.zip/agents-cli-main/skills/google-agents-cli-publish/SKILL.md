---
name: google-agents-cli-publish
description: >
  This skill should be used when the user wants to "publish an agent",
  "publish my ADK agent", "register an agent with Gemini",
  "publish to Gemini" (formerly Gemini Enterprise), or needs guidance on
  the agents-cli publish gemini command.
  Also use when the user wants to "manage agents in Agent Registry",
  "list/update/delete registered agents", or "register an MCP server".
  Covers ADK vs A2A registration modes, programmatic and interactive usage,
  flag reference, auto-detection from deployment metadata, Agent Registry
  fleet management, and troubleshooting.
  Part of the agents-cli skills suite.
  Do NOT use for deployment (use google-agents-cli-deploy).
metadata:
  author: Google
  license: Apache-2.0
  version: 1.13.0
  requires:
    bins:
      - agents-cli
    install: "uv tool install google-agents-cli"
---

# Gemini Registration

> **Requires:** A deployed agent. For Agent Runtime in Gemini platform, `deployment_metadata.json` (created by `agents-cli deploy`) enables auto-detection. For Cloud Run or GKE, provide the agent card URL and flags directly.

## Prerequisites

1. **Agent must be deployed** — the agent must be running and reachable
2. **Gemini app must exist** — Create one in the Google Cloud console before registering
3. **`deployment_metadata.json`** (Agent Runtime only) — Created automatically by `agents-cli deploy`; contains the Agent Runtime ID, deployment target, the A2A flag, and the agent directory
4. **Text-based agent** — Live/voice (bidi) agents are **not supported** by the Gemini app, which has no `/run_live` transport. Register a text-based agent instead.

## Required Permissions for A2A on Cloud Run

- **`roles/run.servicesInvoker`** granted to the Discovery Engine service account (`service-<PROJECT_NUMBER>@gcp-sa-discoveryengine.iam.gserviceaccount.com`) on the Cloud Run service.

---

## Registration Modes

### A2A Registration

Every scaffolded agent serves the Agent-to-Agent protocol. A2A is the default — and only — registration type on **Cloud Run** and **GKE** (no reasoning engine to invoke natively). It also works on **Agent Runtime** via `--registration-type a2a`. For an ADK agent there the CLI warns against it, because the Gemini app can invoke Agent Runtime natively via `:streamQuery` — prefer ADK registration in that case. For an agent built on another framework there is no ADK app to invoke natively, so A2A is the right mode on every target and the warning is expected. Pass the agent card URL and the command fetches the card and registers it; display name and description default to the card's `name`/`description`.

```bash
# A2A on Cloud Run / GKE. The card path depends on the project's language:
#   Python -> /a2a/{app_name}/.well-known/agent-card.json
#   Go     -> /.well-known/agent-card.json
agents-cli publish gemini \
  --agent-card-url https://my-service-abc123.us-east1.run.app/a2a/app/.well-known/agent-card.json \
  --gemini-app-id projects/123456/locations/global/collections/default_collection/engines/my-app
```

Pass `--display-name` / `--description` to override the card defaults. On Agent Runtime, the card URL auto-builds from `deployment_metadata.json` if you omit `--agent-card-url`.

### ADK Registration (default on Agent Runtime)

> **ADK projects only.** The agent must be deployed to Agent Runtime as an ADK app, since
> registration invokes it through `:streamQuery`. An agent on another framework registers over
> A2A, so deploy it to Cloud Run or GKE and publish from there.

This is the **default and recommended registration for ADK agents on Agent Runtime**: the Gemini app invokes the agent natively via `:streamQuery` on its reasoning engine resource, authenticating end-to-end. Under the hood, `:streamQuery` dispatches to the `AdkApp`'s `streaming_agent_run_with_events` method — when debugging an ADK invocation, search the runtime's `reasoning_engine_stderr` logs for that method name to trace the failure. It's also the path to use when the agent needs an OAuth authorization (`--authorization-id`). The agent is registered directly via its reasoning engine resource name; no agent card URL is needed.

```bash
agents-cli publish gemini \
  --registration-type adk \
  --agent-runtime-id projects/123456/locations/us-east1/reasoningEngines/789 \
  --gemini-app-id projects/123456/locations/global/collections/default_collection/engines/my-app \
  --display-name "My Agent" \
  --description "Handles customer queries" \
  --tool-description "Answers questions about products"
```

---

## Programmatic Mode (CI/CD)

The command is non-interactive by default — pass all required values via flags or environment variables. This makes it safe for CI/CD pipelines.

### Via flags

```bash
agents-cli publish gemini \
  --agent-runtime-id "$AGENT_RUNTIME_ID" \
  --gemini-app-id "$GEMINI_APP_ID" \
  --display-name "Production Agent" \
  --registration-type adk
```

### Via environment variables

Most flags have an env var alternative (`--metadata-file`, `--interactive`, and `--list` do not):

```bash
export AGENT_RUNTIME_ID="projects/123456/locations/us-east1/reasoningEngines/789"
export GEMINI_APP_ID="projects/123456/locations/global/collections/default_collection/engines/my-app"
export GEMINI_DISPLAY_NAME="Production Agent"
export GEMINI_DESCRIPTION="Handles customer queries"

agents-cli publish gemini
```

---

## Interactive Mode (`--interactive`)

Pass `--interactive` (or `-i`) to be guided through any missing values with interactive prompts. The command will list available Gemini apps, offer to auto-detect the Agent Runtime ID from metadata, and prompt for display name and description.

```bash
agents-cli publish gemini --interactive
```

---

## Complete Flag Reference

| Flag | Env Var | Description |
|------|---------|-------------|
| `--agent-runtime-id` | `AGENT_RUNTIME_ID` | Agent Runtime resource name (auto-detected from `deployment_metadata.json`) |
| `--gemini-app-id` | `GEMINI_APP_ID` | Gemini app full resource name |
| `--display-name` | `GEMINI_DISPLAY_NAME` | Display name in Gemini |
| `--description` | `GEMINI_DESCRIPTION` | Agent description |
| `--tool-description` | `GEMINI_TOOL_DESCRIPTION` | Tool description (ADK mode only, defaults to description) |
| `--registration-type` | `REGISTRATION_TYPE` | `adk` or `a2a` (defaults to `adk` for an ADK agent on Agent Runtime, `a2a` everywhere else, including any non-ADK framework) |
| `--agent-card-url` | `AGENT_CARD_URL` | Agent card URL for A2A registration |
| `--deployment-target` | `DEPLOYMENT_TARGET` | `agent_runtime`, `cloud_run`, or `gke` (sets the default registration type — ADK on Agent Runtime, A2A on Cloud Run / GKE — and the A2A auth method) |
| `--project-id` | `GOOGLE_CLOUD_PROJECT` | GCP project ID for billing |
| `--project-number` | `PROJECT_NUMBER` | GCP project number (used for Gemini app lookup) |
| `--authorization-id` | `GEMINI_AUTHORIZATION_ID` | OAuth authorization resource name |
| `--metadata-file` | — | Path to deployment metadata (default: `deployment_metadata.json`) |
| `--interactive` / `-i` | — | Enable interactive prompts |
| `--list` | — | List Gemini apps in the current project and exit |

The old names still work as hidden aliases: `publish gemini-enterprise`, `--gemini-enterprise-app-id`, and the `ID` / `GEMINI_ENTERPRISE_APP_ID` env vars. Projects generated by earlier versions call `publish gemini-enterprise` from `make publish-gemini-enterprise`; newer Go and Java projects keep that target and add `make publish-gemini` as an alias.

---

## Auto-Detection from Metadata

When `deployment_metadata.json` exists, the command automatically:

- Reads the **Agent Runtime ID** (`remote_agent_runtime_id`)
- Determines the **registration type**: defaults to **ADK** (native `:streamQuery`) on **Agent Runtime**, and **A2A** on **Cloud Run / GKE** (which have no reasoning engine). A project scaffolded with another framework serves no ADK app, so it defaults to **A2A** on every target. Override with `--registration-type`.
- Determines the **deployment target** for authentication

This means that for the simplest case (an ADK agent on Agent Runtime, registered as ADK), you only need to provide the Gemini app ID:

```bash
agents-cli publish gemini \
  --gemini-app-id projects/123456/locations/global/collections/default_collection/engines/my-app
```

---

## Agent Registry (agents and MCP servers)

Agent Registry (Preview) is the Google Cloud fleet-wide catalog of **agents and MCP servers**, separate from a Gemini app.
Agents deployed to a managed runtime (Agent Runtime in Gemini
platform) are **auto-registered** — no extra step after `agents-cli deploy`.
For A2A projects, `agents-cli deploy` also stores the served agent card on the
engine, so the entry is listed as an A2A agent with the card's skills.
Manage them with `gcloud` (requires `roles/agentregistry.editor`):

```bash
# List / inspect agents
gcloud agent-registry agents list --project PROJECT --location LOCATION
gcloud agent-registry agents describe AGENT_NAME

# Update endpoint/metadata — edit the Service resource, not the Agent
gcloud agent-registry services update AGENT_NAME \
  --display-name "..." --description "..." \
  --interfaces "url=ENDPOINT_URL,protocolBinding=http-json"

# Register an external MCP server: not auto-introspected, so upload a
# toolspec.json (its tools/list response, max 10 KB). No us/eu multi-region.
gcloud agent-registry services create SERVER_NAME --location=LOCATION \
  --mcp-server-spec-type=tool-spec --mcp-server-spec-content=toolspec.json \
  --interfaces="url=SERVER_URL,protocolBinding=jsonrpc"  # or http-json, grpc

# Remove: delete the underlying runtime agent (auto-registered) OR, for
# manually registered agents/servers, delete the Service resource
gcloud agent-registry services delete NAME
```

Terraform: `google_agent_registry_service` with an `mcp_server_spec` block.

Docs: https://docs.cloud.google.com/agent-registry/manage-agents · https://docs.cloud.google.com/agent-registry/register-mcp-servers

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Session not found" after registration | Python projects on `google-cloud-aiplatform` <= 1.128.0 hit a known SDK bug — upgrade it, redeploy, then re-register |
| `--registration-type is required` | Non-interactive mode needs `--registration-type` when no `deployment_metadata.json` exists |
| "Gemini app ID is required" | Provide `--gemini-app-id` or set the `GEMINI_APP_ID` env var |
| Re-publishing the same agent | Registration is idempotent — re-running updates the existing registration in place instead of creating a duplicate |
| HTTP 403 on registration | Check that your account has Discovery Engine Editor permissions on the project that hosts the Gemini app |
| Debugging ADK invocation failures on Agent Runtime | The Gemini app calls the agent via the `AdkApp`'s `streaming_agent_run_with_events` method (the native `:streamQuery` contract). Grep the runtime's `reasoning_engine_stderr` logs for `streaming_agent_run_with_events` to find the underlying error |
| "Could not fetch agent card" | Verify the agent is running and the URL is correct; for Cloud Run, ensure `gcloud auth login` is done. A Live/voice agent drops its A2A card and cannot be published — the Gemini app does not support Live agents |

---

## Related Skills

- `/google-agents-cli-deploy` — Deployment targets, CI/CD pipelines, and production workflows (also covers Agent Gateway governed ingress/egress and Semantic Governance awareness)
- `/google-agents-cli-workflow` — Development workflow, coding guidelines, and operational rules
- `/google-agents-cli-scaffold` — Project creation and enhancement with `agents-cli scaffold create` / `scaffold enhance`
